
import * as React from 'react';
import { 
  Compass, 
  MapPin, 
  Calendar, 
  Sparkles, 
  ChevronRight, 
  Hotel, 
  Utensils, 
  Camera, 
  Clock,
  ExternalLink,
  ArrowRight,
  TrendingUp,
  Plane,
  Star,
  DollarSign,
  Zap,
  Share2,
  ShieldCheck,
  Globe,
  Trash2,
  User,
  LogOut,
  Lock,
  MessageSquare,
  MessageCircle,
  Send,
  X,
  Brain,
  Loader2,
  UserPlus,
  Palmtree,
  Map,
  CreditCard,
  Crown,
  ShieldAlert,
  Car,
  Tent,
  Mountain,
  BookOpen,
  CheckCircle2,
  Heart,
  Smile,
  PartyPopper,
  Coffee,
  LockKeyhole,
  Unlock,
  Shield,
  Accessibility,
  AlertCircle
} from 'lucide-react';
import { 
  generateItinerary, 
  generateBlogPost,
  sendChatMessage, 
  sendFastChatMessage, 
  sendThinkingChatMessage 
} from './geminiService';
import { SearchParams, TripItinerary, BlogPost, Recommendation, MembershipTier } from './types';

const INITIAL_ARTICLES: Partial<BlogPost>[] = [
  {
    id: 'static-1',
    title: "Sipping Coffee in the Clouds: Tokyo's Hidden Roasteries",
    metaDescription: "We crawled the backstreets of Shimokitazawa to find the absolute best beans in Tokyo.",
    imageUrl: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?q=80&w=800&auto=format&fit=crop",
    destination: "Tokyo, Japan",
    createdAt: new Date().toISOString()
  },
  {
    id: 'static-2',
    title: "Pasta & Pixels: A Digital Nomad's Guide to Rome",
    metaDescription: "Where to find 5G wifi and Carbonara that will make you weep with joy.",
    imageUrl: "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?q=80&w=800&auto=format&fit=crop",
    destination: "Rome, Italy",
    createdAt: new Date().toISOString()
  },
  {
    id: 'static-3',
    title: "Bali Blue: The Secret Waterfalls of Ubud",
    metaDescription: "Ditch the beach clubs and head into the jungle for a real reset.",
    imageUrl: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=800&auto=format&fit=crop",
    destination: "Bali, Indonesia",
    createdAt: new Date().toISOString()
  }
];

const HeroMosaic = () => (
  <div className="absolute inset-0 grid grid-cols-2 md:grid-cols-4 gap-4 p-4 md:p-8 opacity-40 -z-10 overflow-hidden">
    <div className="space-y-4 pt-12">
      <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-64 md:h-80 group">
        <img src="https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover" alt="Kyoto" />
      </div>
      <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-48 md:h-64 group">
        <img src="https://images.unsplash.com/photo-1511739001486-6bfe10ce785f?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover" alt="Paris" />
      </div>
    </div>
    <div className="space-y-4">
      <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-72 md:h-96 group">
        <img src="https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover" alt="Venice" />
      </div>
      <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-56 md:h-72 group">
        <img src="https://images.unsplash.com/photo-1506929197914-43221c3b948d?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover" alt="Santorini" />
      </div>
    </div>
    <div className="space-y-4 pt-8">
      <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-64 md:h-80 group">
        <img src="https://images.unsplash.com/photo-1516483638261-f4dbaf036963?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover" alt="Amalfi Coast" />
      </div>
      <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-72 md:h-96 group">
        <img src="https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover" alt="Tokyo" />
      </div>
    </div>
    <div className="space-y-4">
      <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-48 md:h-64 group">
        <img src="https://images.unsplash.com/photo-1518391846015-55a9cc003b25?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover" alt="New York" />
      </div>
      <div className="rounded-[2.5rem] overflow-hidden shadow-2xl h-80 md:h-[30rem] group">
        <img src="https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover" alt="Bali" />
      </div>
    </div>
  </div>
);

const ChatBot = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const [mode, setMode] = React.useState<'standard' | 'fast' | 'thinking'>('standard');
  const [messages, setMessages] = React.useState<{ role: 'user' | 'ai', text: string, type?: string }[]>([
    { role: 'ai', text: "Hey Bestie! I've been checking out some amazing spots lately. Where should we head next?" }
  ]);
  const [input, setInput] = React.useState('');
  const [isLoading, setIsLoading] = React.useState(false);
  const scrollRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    const userMsg = input.trim();
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setInput('');
    setIsLoading(true);
    try {
      let response: string | undefined;
      if (mode === 'fast') response = await sendFastChatMessage(userMsg);
      else if (mode === 'thinking') response = await sendThinkingChatMessage(userMsg);
      else {
        const history = messages.slice(-6).map(m => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.text }]
        }));
        response = await sendChatMessage(userMsg, history);
      }
      setMessages(prev => [...prev, { role: 'ai', text: response || "Ouch, my connection dropped! Try again?", type: mode }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'ai', text: "My brain is a bit fuzzy right now, let's try that again!" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[200]">
      {!isOpen ? (
        <button 
          onClick={() => setIsOpen(true)}
          className="vibrant-gradient text-white p-5 rounded-full shadow-[var(--shadow-orange)] hover:scale-110 transition-all group border-4 border-white"
        >
          <MessageCircle className="w-8 h-8 group-hover:rotate-12 transition-transform" />
        </button>
      ) : (
        <div className="bg-white rounded-[2.5rem] w-[90vw] max-w-[420px] h-[650px] shadow-2xl border-4 border-[var(--whisk-orange)] flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 duration-500">
          <div className="vibrant-gradient p-6 text-white flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-white/30 p-2 rounded-2xl">
                <Smile className="w-6 h-6" />
              </div>
              <div>
                <h4 className="font-black text-lg tracking-tight">Whisk Bestie</h4>
                <div className="flex gap-2 mt-1">
                  <button onClick={() => setMode('standard')} className={`text-[10px] uppercase font-black px-3 py-1 rounded-full transition-all ${mode === 'standard' ? 'bg-white text-[var(--whisk-orange)]' : 'bg-white/20 text-white'}`}>Chat</button>
                  <button onClick={() => setMode('fast')} className={`text-[10px] uppercase font-black px-3 py-1 rounded-full transition-all ${mode === 'fast' ? 'bg-white text-[var(--whisk-orange)]' : 'bg-white/20 text-white'}`}>Quick</button>
                  <button onClick={() => setMode('thinking')} className={`text-[10px] uppercase font-black px-3 py-1 rounded-full transition-all ${mode === 'thinking' ? 'bg-white text-[var(--whisk-orange)]' : 'bg-white/20 text-white'}`}>Deep</button>
                </div>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:bg-white/20 p-2 rounded-xl transition-colors"><X className="w-6 h-6" /></button>
          </div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-5 bg-[var(--whisk-sky)]/30">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] p-5 rounded-3xl text-sm font-medium leading-relaxed ${m.role === 'user' ? 'vibrant-gradient text-white rounded-tr-none shadow-lg' : 'bg-white text-slate-800 shadow-xl shadow-slate-200/50 border border-white rounded-tl-none'}`}>
                  {m.role === 'ai' && m.type === 'thinking' && <div className="flex items-center gap-1.5 text-[10px] font-black text-[var(--whisk-purple)] uppercase tracking-widest mb-2"><Brain className="w-4 h-4" /> Thinking deeply...</div>}
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white p-5 rounded-3xl rounded-tl-none shadow-lg flex items-center gap-3">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-[var(--whisk-orange)] rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-[var(--whisk-orange)] rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-[var(--whisk-orange)] rounded-full animate-bounce delay-200"></div>
                  </div>
                  <span className="text-sm text-slate-400 font-bold italic">Checking my notes...</span>
                </div>
              </div>
            )}
          </div>
          <div className="p-5 bg-white border-t border-slate-100 flex gap-3">
            <input type="text" placeholder="Talk to me..." className="flex-1 bg-slate-50 border-2 border-slate-100 rounded-2xl py-4 px-5 text-sm outline-none focus:ring-4 focus:ring-[var(--focus-ring)] focus:border-[var(--whisk-cyan)] transition-all font-medium" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSend()} />
            <button onClick={handleSend} disabled={isLoading || !input.trim()} className="vibrant-gradient text-white p-4 rounded-2xl hover:scale-105 transition-all disabled:opacity-50"><Send className="w-6 h-6" /></button>
          </div>
        </div>
      )}
    </div>
  );
};

const Navbar = ({ isLoggedIn, membershipTier, onHome, onMyTrips, onSignIn, onLogOut, activeTab, onUpgrade }: any) => (
  <nav className="sticky top-0 z-50 glass-panel shadow-xl shadow-slate-200/20">
    <div className="max-w-7xl mx-auto px-6 sm:px-10">
      <div className="flex justify-between items-center h-24">
        <button onClick={onHome} className="flex items-center gap-4 hover:opacity-90 transition-all group">
          <div className="vibrant-gradient p-3 rounded-2xl shadow-[var(--shadow-orange)] group-hover:scale-110 group-hover:rotate-6 transition-all">
            <Plane className="text-white w-7 h-7" />
          </div>
          <span className="text-3xl font-black tracking-tighter uppercase text-[var(--whisk-navy)]">Whisk</span>
        </button>
        <div className="hidden md:flex items-center space-x-12">
          <button onClick={onHome} className={`text-sm font-black uppercase tracking-[0.2em] transition-all hover:scale-105 ${activeTab === 'home' ? 'text-[var(--whisk-orange)]' : 'text-slate-400 hover:text-[var(--whisk-navy)]'}`}>Discover</button>
          {isLoggedIn && membershipTier !== 'Wanderer' && <button onClick={onMyTrips} className={`text-sm font-black uppercase tracking-[0.2em] transition-all hover:scale-105 ${activeTab === 'my-trips' ? 'text-[var(--whisk-orange)]' : 'text-slate-400 hover:text-[var(--whisk-navy)]'}`}>My Trips</button>}
          <div className="h-10 w-0.5 bg-slate-100 mx-2"></div>
          {isLoggedIn ? (
            <div className="flex items-center gap-6">
              {membershipTier === 'Wanderer' && (
                <button onClick={onUpgrade} className="cyan-gradient text-white px-8 py-3 rounded-full text-xs font-black uppercase tracking-widest hover:scale-105 transition-all shadow-[var(--shadow-cyan)] flex items-center gap-2">
                  <Sparkles className="w-4 h-4" />Get All Access
                </button>
              )}
              <button className="flex items-center gap-3 text-xs font-black bg-slate-50 text-[var(--whisk-navy)] px-6 py-3 rounded-full hover:bg-slate-100 transition-all uppercase tracking-widest border-2 border-slate-100">
                <User className="w-4 h-4 text-[var(--whisk-orange)]" />Me
              </button>
              <button onClick={onLogOut} className="text-slate-300 hover:text-red-500 transition-colors"><LogOut className="w-6 h-6" /></button>
            </div>
          ) : (
            <button onClick={onSignIn} className="vibrant-gradient text-white px-10 py-4 rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-105 transition-all shadow-[var(--shadow-orange)] flex items-center gap-3">
              Join The Club
            </button>
          )}
        </div>
      </div>
    </div>
  </nav>
);

const TrustTabs = () => {
  const [activeTab, setActiveTab] = React.useState(0);
  const tabs = [
    { 
      title: "Our Vibe", 
      content: "We're not some corporate travel agency. We're a group of friends who were tired of scrolling through paid ads and generic lists. Whisk was born to find the soul of a city, not just the airport hotel.",
      icon: <Smile className="w-8 h-8" />
    },
    { 
      title: "Expert Vetting", 
      content: "Every recommendation is cross-referenced with local data and expert blogs. We don't just follow the crowd; we follow the people who actually live there. If a spot goes downhill, we remove it. Fast.",
      icon: <ShieldCheck className="w-8 h-8" />
    },
    { 
      title: "Community First", 
      content: "Thousands of besties have used Whisk to find their new favorite pizza in Rome or a secret sunset hike in Maui. We're building a network of trust that grows with every single trip planned.",
      icon: <Heart className="w-8 h-8" />
    }
  ];

  return (
    <div className="mt-8 bg-slate-50 rounded-[3rem] p-8 md:p-10 border-2 border-white shadow-lg w-full">
      <div className="flex items-center gap-4 mb-6">
        <div className="vibrant-gradient p-2.5 rounded-xl text-white shadow-md">
          <MapPin className="w-5 h-5" />
        </div>
        <h3 className="text-2xl font-black text-[var(--whisk-navy)] tracking-tight">As a local...</h3>
      </div>
      <div className="flex gap-3 mb-6 overflow-x-auto pb-2 no-scrollbar">
        {tabs.map((tab, i) => (
          <button
            key={i}
            onClick={() => setActiveTab(i)}
            className={`px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
              activeTab === i 
              ? 'vibrant-gradient text-white shadow-md' 
              : 'bg-white text-slate-400 hover:text-slate-600'
            }`}
          >
            {tab.title}
          </button>
        ))}
      </div>
      <div className="animate-in fade-in slide-in-from-left-2 duration-300">
        <p className="text-slate-500 text-base font-medium leading-relaxed">
          {tabs[activeTab].content}
        </p>
      </div>
    </div>
  );
};

const BlogFeed = ({ posts, onView, title = "Community Field Guides" }: { posts: BlogPost[], onView: (post: BlogPost) => void, title?: string }) => (
  <section className="py-24 bg-white relative">
    <div className="max-w-7xl mx-auto px-6 sm:px-10">
      <div className="flex flex-col md:flex-row justify-between items-center md:items-end mb-16 gap-8">
        <div className="text-center md:text-left">
          <div className="inline-flex items-center gap-2 bg-[var(--whisk-orange)]/10 text-[var(--whisk-orange)] px-5 py-2 rounded-full text-[12px] font-black uppercase tracking-widest mb-6">
            <BookOpen className="w-4 h-4" /> {title}
          </div>
          <h2 className="text-5xl font-black mb-6 tracking-tighter text-[var(--whisk-navy)]">Expert Intel & Inspo</h2>
          <p className="text-slate-500 text-lg font-medium max-w-2xl">Read up on the world's most vibrant spots before you go.</p>
        </div>
      </div>
      <div className="grid md:grid-cols-3 gap-10">
        {posts.map((post: BlogPost) => (
          <div key={post.id} className="bg-slate-50/50 rounded-[3rem] overflow-hidden shadow-2xl hover:shadow-orange-500/10 transition-all group cursor-pointer border-2 border-white" onClick={() => onView(post)}>
            <div className="relative h-72 overflow-hidden">
              <img src={post.imageUrl} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" alt={post.title} />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
              <div className="absolute bottom-6 left-8 text-white">
                <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-[0.4em] mb-1 opacity-90"><MapPin className="w-3 h-3" />{post.destination}</div>
                <h3 className="text-2xl font-black tracking-tight leading-tight">{post.title}</h3>
              </div>
            </div>
            <div className="p-8">
              <p className="text-slate-500 font-medium text-sm line-clamp-2 mb-6 leading-relaxed">{post.metaDescription}</p>
              <div className="flex items-center justify-between pt-6 border-t border-slate-100">
                 <div className="flex items-center gap-3">
                     <div className="w-8 h-8 rounded-xl vibrant-gradient flex items-center justify-center text-white text-[10px] font-black shadow-md">W</div>
                     <span className="text-[10px] font-black text-slate-800 uppercase tracking-widest">Whisk Team</span>
                 </div>
                 <span className="text-[10px] font-bold text-slate-400 uppercase">{new Date(post.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);

const ActionSidebar = ({ recommendations, destination }: { recommendations: Recommendation[], destination: string }) => {
  const destinationQuery = encodeURIComponent(destination);
  return (
    <div className="sticky top-24 space-y-12">
      <div className="bg-white rounded-[4rem] p-10 shadow-2xl border-4 border-[var(--whisk-orange)] relative overflow-hidden">
        <h3 className="text-3xl font-black mb-10 flex items-center gap-5 text-[var(--whisk-navy)] tracking-tighter">Booking Hub</h3>
        <div className="space-y-10 relative z-10">
          {recommendations.map((rec: Recommendation, i: number) => (
            <div key={i} className="bg-slate-50 rounded-[2rem] p-8 hover:bg-white hover:shadow-xl transition-all group border-2 border-transparent hover:border-[var(--whisk-orange)]/10">
              <div className="flex items-center justify-between mb-6">
                 <div className="flex items-center gap-3">
                    <div className="vibrant-gradient p-3 rounded-xl shadow-lg text-white">
                      {rec.type === 'hotel' ? <Hotel className="w-6 h-6" /> : rec.type === 'restaurant' ? <Utensils className="w-6 h-6" /> : rec.type === 'flight' ? <Plane className="w-6 h-6" /> : <Camera className="w-6 h-6" />}
                    </div>
                    <span className="text-[10px] font-black uppercase tracking-[0.4em] text-[var(--whisk-orange)]">{rec.type}</span>
                 </div>
                 {rec.price && (
                   <div className="bg-[var(--whisk-cyan)]/10 text-[var(--whisk-cyan)] px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                     {rec.price}
                   </div>
                 )}
              </div>
              <h4 className="font-black text-xl mb-2 tracking-tight text-[var(--whisk-navy)] leading-tight">{rec.name}</h4>
              {rec.availability && (
                <div className="flex items-center gap-2 mb-4 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                  <AlertCircle className="w-3 h-3 text-[var(--whisk-orange)]" />
                  {rec.availability}
                </div>
              )}
              <p className="text-slate-500 text-sm mb-8 leading-relaxed font-medium line-clamp-2">{rec.description}</p>
              <a href={rec.affiliateUrl} target="_blank" className="w-full vibrant-gradient text-white py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.4em] flex items-center justify-center gap-3 hover:scale-105 transition-all shadow-lg">
                Book Now <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          ))}
        </div>
      </div>
      <div className="bg-[var(--whisk-navy)] rounded-[4rem] p-10 shadow-2xl text-white">
        <h3 className="text-2xl font-black mb-8 flex items-center gap-4 tracking-tighter"><Plane className="text-[var(--whisk-cyan)] w-8 h-8" />Get Around</h3>
        <div className="space-y-4">
          <a href="https://uber.com" target="_blank" className="w-full bg-white/10 text-white p-5 rounded-3xl font-black text-[10px] uppercase tracking-[0.3em] flex items-center justify-between hover:bg-white/20 transition-all">Uber Anywhere <ArrowRight className="w-4 h-4" /></a>
          <a href={`https://kayak.com/cars/${destinationQuery}`} target="_blank" className="w-full cyan-gradient text-white p-5 rounded-3xl font-black text-[10px] uppercase tracking-[0.3em] flex items-center justify-between hover:scale-105 transition-all">Rent a Car <ArrowRight className="w-4 h-4" /></a>
        </div>
      </div>
    </div>
  );
};

const BlogPostDisplay = ({ post, itinerary, onBack }: { post: BlogPost, itinerary: TripItinerary, onBack: () => void }) => {
  const contentHtml = post.content
    ? post.content
        .replace(/## (.*)/g, '<h2 class="text-3xl font-black tracking-tighter text-[var(--whisk-navy)] mt-12 mb-6">$1</h2>')
        .replace(/\* (.*)/g, '<li class="mb-3 text-lg text-slate-600 leading-relaxed font-medium">$1</li>')
        .replace(/> (.*)/g, '<blockquote class="border-l-8 border-[var(--whisk-cyan)] bg-[var(--whisk-sky)] p-8 my-8 text-xl font-bold italic text-slate-700 rounded-r-3xl">$1</blockquote>')
        .replace(/(\r\n|\n\r|\r|\n)/g, '<br />')
    : "<p>Stay tuned for this Bestie's travel story!</p>";

  return (
    <div className="max-w-7xl mx-auto px-6 sm:px-10 py-20 animate-in fade-in duration-500">
        <button onClick={onBack} className="flex items-center gap-2 font-black text-sm uppercase tracking-widest text-[var(--whisk-orange)] hover:-translate-x-1 transition-transform mb-12">
          <ChevronRight className="w-5 h-5 rotate-180" /> Back to Discover
        </button>
        <div className="grid lg:grid-cols-3 gap-16">
          <div className="lg:col-span-2 bg-white rounded-[3rem] shadow-2xl border-4 border-white overflow-hidden">
             <img src={post.imageUrl} className="w-full h-[400px] object-cover" alt={post.title} />
             <div className="p-10 md:p-20">
               <div className="mb-10">
                  <div className="flex items-center gap-2 text-[var(--whisk-orange)] font-black uppercase tracking-[0.4em] text-[10px] mb-4">
                      <MapPin className="w-4 h-4" /> Field Guide
                  </div>
                  <h1 className="text-5xl md:text-7xl font-black text-[var(--whisk-navy)] tracking-tighter leading-tight">{post.title}</h1>
               </div>
               <p className="text-xl text-slate-500 font-medium italic mb-12 border-l-4 border-[var(--whisk-orange)]/20 pl-6">{post.metaDescription}</p>
               <div className="prose lg:prose-xl max-w-none text-slate-700" dangerouslySetInnerHTML={{ __html: contentHtml }} style={{ whiteSpace: 'pre-wrap' }}></div>
             </div>
          </div>
          <div className="space-y-12">
            <ActionSidebar recommendations={itinerary.recommendations} destination={itinerary.destination} />
          </div>
        </div>
    </div>
  )
}

const MembershipModal = ({ isOpen, onClose, onSelectTier }: { isOpen: boolean, onClose: () => void, onSelectTier: (tier: MembershipTier) => void }) => {
  if (!isOpen) return null;
  
  const tiers: { name: MembershipTier, price: string, features: string[], icon: React.ReactNode, color: string }[] = [
    {
      name: 'Wanderer',
      price: 'Free',
      features: ['Basic AI planning', 'Community guides', 'Public itineraries'],
      icon: <Palmtree className="w-8 h-8" />,
      color: 'bg-slate-100'
    },
    {
      name: 'Explorer',
      price: '$9/mo',
      features: ['Unlock all itineraries', 'Deep research mode', 'Ad-free experience', 'Priority support'],
      icon: <Compass className="w-8 h-8" />,
      color: 'cyan-gradient'
    },
    {
      name: 'Cartographer',
      price: '$19/mo',
      features: ['Everything in Explorer', 'Offline map exports', 'Personal travel concierge', 'Early access features'],
      icon: <Crown className="w-8 h-8" />,
      color: 'vibrant-gradient'
    }
  ];

  return (
    <div className="fixed inset-0 z-[300] flex items-center justify-center p-6 bg-[var(--whisk-navy)]/60 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="bg-white rounded-[4rem] w-full max-w-5xl overflow-hidden shadow-2xl relative">
        <button onClick={onClose} className="absolute top-10 right-10 p-4 hover:bg-slate-100 rounded-2xl transition-colors">
          <X className="w-8 h-8" />
        </button>
        <div className="p-12 md:p-20">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-black mb-4 tracking-tighter text-[var(--whisk-navy)]">Level Up Your Travels</h2>
            <p className="text-xl text-slate-500 font-medium">Choose the tier that fits your journey.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {tiers.map((tier) => (
              <div key={tier.name} className="bg-slate-50 rounded-[3rem] p-10 flex flex-col border-4 border-white hover:border-[var(--whisk-orange)]/20 transition-all group">
                <div className={`${tier.color} ${tier.name === 'Wanderer' ? 'text-slate-400' : 'text-white'} p-6 rounded-3xl w-fit mb-8 shadow-lg group-hover:scale-110 transition-transform`}>
                  {tier.icon}
                </div>
                <h3 className="text-2xl font-black mb-2 text-[var(--whisk-navy)] tracking-tight">{tier.name}</h3>
                <div className="text-3xl font-black mb-8 text-[var(--whisk-orange)]">{tier.price}</div>
                <ul className="space-y-4 mb-10 flex-1">
                  {tier.features.map((f, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm font-medium text-slate-500">
                      <CheckCircle2 className="w-5 h-5 text-[var(--whisk-cyan)] shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <button 
                  onClick={() => onSelectTier(tier.name)}
                  className={`w-full py-5 rounded-2xl font-black uppercase tracking-widest text-xs transition-all ${tier.name === 'Wanderer' ? 'bg-white text-slate-400 border-2 border-slate-200' : 'vibrant-gradient text-white shadow-lg hover:scale-105'}`}
                >
                  Choose {tier.name}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const ItinerarySkeleton = ({ statusText }: { statusText: string }) => (
  <div className="min-h-screen bg-white flex flex-col items-center justify-center p-10">
    <div className="relative mb-16">
      <div className="w-32 h-32 border-8 border-slate-100 rounded-full"></div>
      <div className="absolute inset-0 w-32 h-32 border-8 border-t-[var(--whisk-orange)] border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin"></div>
      <Plane className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-10 h-10 text-[var(--whisk-orange)] animate-pulse" />
    </div>
    <h3 className="text-4xl font-black text-[var(--whisk-navy)] mb-6 tracking-tighter text-center">Sit tight, bestie!</h3>
    <p className="text-xl text-slate-400 font-bold italic animate-bounce">{statusText}</p>
    <div className="mt-20 max-w-2xl w-full space-y-8 opacity-40">
       <div className="h-10 bg-slate-100 rounded-full w-3/4 mx-auto animate-pulse"></div>
       <div className="grid grid-cols-2 gap-8">
         <div className="h-64 bg-slate-100 rounded-[3rem] animate-pulse"></div>
         <div className="h-64 bg-slate-100 rounded-[3rem] animate-pulse delay-75"></div>
       </div>
       <div className="h-40 bg-slate-100 rounded-[3rem] animate-pulse delay-150"></div>
    </div>
  </div>
);

const ItineraryDisplay = ({ itinerary, onUnlock }: { itinerary: TripItinerary, onRateActivity: any, onRateOverall: any, onUnlock: () => void }) => {
  return (
    <div className="max-w-7xl mx-auto px-6 sm:px-10 py-20 animate-in slide-in-from-bottom-10 duration-700">
       <div className="mb-20 text-center">
          <div className="inline-flex items-center gap-2 bg-[var(--whisk-orange)]/10 text-[var(--whisk-orange)] px-6 py-2 rounded-full text-[12px] font-black uppercase tracking-widest mb-8">Generated Itinerary</div>
          <h1 className="text-6xl md:text-8xl font-black text-[var(--whisk-navy)] mb-8 tracking-tighter leading-tight">{itinerary.title}</h1>
          <p className="text-2xl text-slate-500 font-medium max-w-3xl mx-auto leading-relaxed italic">"{itinerary.summary}"</p>
       </div>

       <div className="grid lg:grid-cols-3 gap-16">
          <div className="lg:col-span-2 space-y-12">
            {itinerary.days.map((day, dIdx) => (
              <div key={dIdx} className="bg-white rounded-[4rem] p-10 md:p-16 shadow-2xl border-4 border-white relative overflow-hidden group">
                 <div className="absolute top-0 right-0 w-64 h-64 bg-[var(--whisk-orange)]/5 rounded-full -mr-32 -mt-32 transition-transform group-hover:scale-125 duration-700"></div>
                 <div className="relative z-10">
                    <div className="flex items-center gap-6 mb-12">
                       <div className="vibrant-gradient w-20 h-20 rounded-3xl flex items-center justify-center text-white text-3xl font-black shadow-xl">
                          {day.dayNumber}
                       </div>
                       <div>
                          <div className="text-[10px] font-black text-[var(--whisk-orange)] uppercase tracking-[0.4em] mb-1">Day Plan</div>
                          <h2 className="text-4xl font-black text-[var(--whisk-navy)] tracking-tight">{day.theme}</h2>
                       </div>
                    </div>
                    
                    <div className={`space-y-10 transition-all duration-700 ${!itinerary.unlocked && dIdx > 0 ? 'blur-md pointer-events-none select-none opacity-40' : ''}`}>
                       {day.activities.map((activity, aIdx) => (
                         <div key={aIdx} className="flex gap-8 relative">
                            {aIdx < day.activities.length - 1 && <div className="absolute left-6 top-16 bottom-0 w-1 bg-slate-100"></div>}
                            <div className="bg-slate-50 p-4 rounded-2xl h-fit border-2 border-white shadow-sm shrink-0">
                               <Clock className="w-5 h-5 text-slate-400" />
                            </div>
                            <div className="space-y-3">
                               <span className="text-xs font-black text-[var(--whisk-cyan)] uppercase tracking-widest">{activity.time}</span>
                               <h4 className="text-2xl font-black text-[var(--whisk-navy)] tracking-tight">{activity.location}</h4>
                               <p className="text-slate-500 font-medium leading-relaxed">{activity.description}</p>
                            </div>
                         </div>
                       ))}
                    </div>

                    {!itinerary.unlocked && dIdx > 0 && (
                      <div className="absolute inset-0 flex items-center justify-center p-10 z-20">
                         <div className="bg-white/80 backdrop-blur-md p-10 rounded-[3rem] text-center shadow-2xl border-2 border-white max-w-md">
                            <LockKeyhole className="w-16 h-16 text-[var(--whisk-orange)] mx-auto mb-6" />
                            <h4 className="text-2xl font-black text-[var(--whisk-navy)] mb-4 tracking-tighter">This part is hidden!</h4>
                            <p className="text-slate-500 font-medium mb-8">Unlock the full itinerary to see every hidden gem and secret spot we've found for you.</p>
                            <button onClick={onUnlock} className="w-full vibrant-gradient text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs shadow-lg hover:scale-105 transition-all">Unlock All Days</button>
                         </div>
                      </div>
                    )}
                 </div>
              </div>
            ))}
          </div>
          
          <div className="space-y-12">
             <ActionSidebar recommendations={itinerary.recommendations} destination={itinerary.destination} />
             {itinerary.blogPost && (
                <div className="bg-white rounded-[3rem] p-10 shadow-xl border-4 border-white hover:border-[var(--whisk-orange)]/20 transition-all group">
                   <h4 className="text-2xl font-black text-[var(--whisk-navy)] mb-6 tracking-tight">Our Deep Dive</h4>
                   <img src={itinerary.blogPost.imageUrl} className="w-full h-48 object-cover rounded-3xl mb-8" alt="Blog" />
                   <h5 className="font-black text-xl mb-4 text-[var(--whisk-navy)] leading-tight">{itinerary.blogPost.title}</h5>
                   <p className="text-slate-500 text-sm font-medium mb-8 line-clamp-2">{itinerary.blogPost.metaDescription}</p>
                </div>
             )}
          </div>
       </div>
    </div>
  );
};

const TripPlannerForm = ({ onGenerate, loading }: any) => {
  const [params, setParams] = React.useState<SearchParams>({ 
    destination: '', 
    duration: '3 days', 
    interests: [], 
    budget: 'Mid-range', 
    pace: 'Moderate', 
    accessibility: [] 
  });
  
  const toggleInterest = (interest: string) => setParams(prev => ({ 
    ...prev, 
    interests: prev.interests.includes(interest) ? prev.interests.filter(i => i !== interest) : [...prev.interests, interest] 
  }));

  const toggleAccessibility = (item: string) => setParams(prev => ({ 
    ...prev, 
    accessibility: prev.accessibility.includes(item) ? prev.accessibility.filter(i => i !== item) : [...prev.accessibility, item] 
  }));

  const accessibilityOptions = [
    'Wheelchair Access',
    'Limited Walking',
    'Elevators Only',
    'Quiet Spaces',
    'Service Animal Friendly',
    'Braille Signage',
    'Low Sensory'
  ];

  return (
    <div className="relative py-24 md:py-32 overflow-hidden bg-[var(--whisk-navy)]">
      <img src="https://images.unsplash.com/photo-1469854523086-cc02fe5d8df9?q=80&w=2021&auto=format&fit=crop" className="absolute inset-0 w-full h-full object-cover opacity-30 blur-[2px]" alt="Iconic Travel Backdrop" />
      <div className="absolute inset-0 bg-gradient-to-br from-[var(--whisk-navy)]/80 via-transparent to-[var(--whisk-orange)]/20"></div>

      <div className="max-w-5xl mx-auto px-6 relative z-10">
        <div className="bg-white/95 backdrop-blur-md rounded-[4rem] p-10 md:p-20 shadow-2xl border-4 border-white/50 relative">
          <div className="mb-12 text-center">
            <div className="inline-flex items-center gap-2 bg-[var(--whisk-orange)]/10 text-[var(--whisk-orange)] px-6 py-2 rounded-full text-[12px] font-black uppercase tracking-widest mb-8">Trip Planner</div>
            <h2 className="text-6xl font-black mb-4 tracking-tighter text-[var(--whisk-navy)]">Where next, bestie?</h2>
            <p className="text-slate-500 font-medium text-xl">Give me the vibes, and I'll do the rest.</p>
          </div>
          <div className="space-y-12">
            <div className="grid md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <label className="text-[12px] font-black uppercase tracking-[0.4em] text-slate-400 ml-6">Destinaton</label>
                <div className="relative group">
                  <MapPin className="absolute left-8 top-1/2 -translate-y-1/2 text-[var(--whisk-orange)] w-7 h-7" />
                  <input type="text" placeholder="Bali, London, Mars..." className="w-full bg-slate-50 border-4 border-transparent rounded-[2.5rem] py-6 pl-20 pr-10 outline-none focus:ring-8 focus:ring-[var(--focus-ring)] focus:bg-white transition-all text-xl font-black text-[var(--whisk-navy)]" value={params.destination} onChange={e => setParams({...params, destination: e.target.value})} />
                </div>
              </div>
              <div className="space-y-4">
                <label className="text-[12px] font-black uppercase tracking-[0.4em] text-slate-400 ml-6">How many days?</label>
                <div className="relative group">
                  <Calendar className="absolute left-8 top-1/2 -translate-y-1/2 text-[var(--whisk-orange)] w-7 h-7" />
                  <select className="w-full bg-slate-50 border-4 border-transparent rounded-[2.5rem] py-6 pl-20 pr-10 outline-none focus:ring-8 focus:ring-[var(--focus-ring)] focus:bg-white transition-all text-xl font-black text-[var(--whisk-navy)] appearance-none cursor-pointer" value={params.duration} onChange={e => setParams({...params, duration: e.target.value})}>
                    {[2,3,4,5,7,10,14,21].map(d => <option key={d} value={`${d} days`}>{d} Days</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <label className="text-[12px] font-black uppercase tracking-[0.4em] text-slate-400 ml-6">Budget</label>
                <div className="relative group">
                  <DollarSign className="absolute left-8 top-1/2 -translate-y-1/2 text-[var(--whisk-orange)] w-7 h-7" />
                  <select className="w-full bg-slate-50 border-4 border-transparent rounded-[2.5rem] py-6 pl-20 pr-10 outline-none focus:ring-8 focus:ring-[var(--focus-ring)] focus:bg-white transition-all text-xl font-black text-[var(--whisk-navy)] appearance-none cursor-pointer" value={params.budget} onChange={e => setParams({...params, budget: e.target.value as any})}>
                    <option value="Budget">Shoestring</option>
                    <option value="Mid-range">Comfortable</option>
                    <option value="Luxury">All Out</option>
                  </select>
                </div>
              </div>
              <div className="space-y-4">
                <label className="text-[12px] font-black uppercase tracking-[0.4em] text-slate-400 ml-6">Energy Level</label>
                <div className="relative group">
                  <Zap className="absolute left-8 top-1/2 -translate-y-1/2 text-[var(--whisk-orange)] w-7 h-7" />
                  <select className="w-full bg-slate-50 border-4 border-transparent rounded-[2.5rem] py-6 pl-20 pr-10 outline-none focus:ring-8 focus:ring-[var(--focus-ring)] focus:bg-white transition-all text-xl font-black text-[var(--whisk-navy)] appearance-none cursor-pointer" value={params.pace} onChange={e => setParams({...params, pace: e.target.value as any})}>
                    <option value="Relaxed">Chill Vibes</option>
                    <option value="Moderate">A Bit of Everything</option>
                    <option value="Fast-paced">Let's Go Everywhere</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <label className="text-[12px] font-black uppercase tracking-[0.4em] text-slate-400 ml-6">Vibes We Want</label>
              <div className="flex flex-wrap gap-3">
                {['Fine Dining', 'Art & Culture', 'Nature', 'Extreme Adventure', 'Shopping', 'Hidden Gems', 'Relaxing', 'Sports'].map(interest => (
                  <button key={interest} onClick={() => toggleInterest(interest)} className={`px-6 py-3 rounded-[2rem] text-sm font-black uppercase tracking-widest transition-all border-4 ${params.interests.includes(interest) ? 'vibrant-gradient border-transparent text-white shadow-xl scale-110' : 'bg-slate-50 border-transparent text-slate-400 hover:bg-slate-100 hover:text-[var(--whisk-navy)]'}`}>{interest}</button>
                ))}
              </div>
            </div>

            <div className="space-y-8">
              <div className="flex items-center gap-4 ml-6">
                <Accessibility className="w-5 h-5 text-slate-400" />
                <label className="text-[12px] font-black uppercase tracking-[0.4em] text-slate-400">Accessibility Needs</label>
              </div>
              <div className="flex flex-wrap gap-3">
                {accessibilityOptions.map(option => (
                  <button key={option} onClick={() => toggleAccessibility(option)} className={`px-6 py-3 rounded-[2rem] text-sm font-black uppercase tracking-widest transition-all border-4 ${params.accessibility.includes(option) ? 'cyan-gradient border-transparent text-white shadow-xl scale-110' : 'bg-slate-50 border-transparent text-slate-400 hover:bg-slate-100 hover:text-[var(--whisk-navy)]'}`}>{option}</button>
                ))}
              </div>
            </div>

            <button onClick={() => onGenerate(params)} disabled={loading || !params.destination} className={`w-full py-8 rounded-[3rem] font-black uppercase tracking-[0.5em] text-lg flex items-center justify-center gap-6 transition-all ${loading || !params.destination ? 'bg-slate-100 text-slate-300' : 'vibrant-gradient text-white hover:scale-105 shadow-[var(--shadow-orange)]'}`}>
              {loading ? <div className="flex gap-2"><div className="w-3 h-3 bg-white rounded-full animate-bounce"></div><div className="w-3 h-3 bg-white rounded-full animate-bounce delay-100"></div></div> : <Compass className="w-8 h-8" />}
              {loading ? "Sorting it out, hang tight!" : 'Plan My Trip!'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  const [loading, setLoading] = React.useState(false);
  const [loadingStatus, setLoadingStatus] = React.useState('');
  const [itinerary, setItinerary] = React.useState<TripItinerary | null>(null);
  const [showForm, setShowForm] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState<'home' | 'my-trips'>('home');
  const [recentTrips, setRecentTrips] = React.useState<TripItinerary[]>([]);
  const [viewingData, setViewingData] = React.useState<{post: BlogPost, itinerary: TripItinerary} | null>(null);
  const [isMembershipModalOpen, setIsMembershipModalOpen] = React.useState(false);
  const [isLoggedIn, setIsLoggedIn] = React.useState(false);
  const [membershipTier, setMembershipTier] = React.useState<MembershipTier | null>(null);


  React.useEffect(() => {
    const savedTrips = localStorage.getItem('whisk_trips');
    const authStatus = localStorage.getItem('whisk_auth');
    const tier = localStorage.getItem('whisk_tier') as MembershipTier;
    if (savedTrips) setRecentTrips(JSON.parse(savedTrips));
    if (authStatus === 'true') {
      setIsLoggedIn(true);
      setMembershipTier(tier || 'Wanderer');
    }
  }, []);

  const handleGenerate = async (params: SearchParams) => {
    setLoading(true);
    setLoadingStatus('Mapping your perfect trip...');
    setShowForm(false);
    setItinerary(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    try {
      const itineraryResult = await generateItinerary(params);
      const blogPostResult = await generateBlogPost(itineraryResult);
      
      const newBlogPost: BlogPost = {
        ...blogPostResult,
        id: Math.random().toString(36).substring(7),
        imageUrl: `https://images.unsplash.com/photo-1528127269322-539801943592?q=80&w=800&auto=format&fit=crop&destination=${encodeURIComponent(params.destination)}`,
        createdAt: new Date().toISOString(),
      };
      
      const finalItinerary: TripItinerary = { 
        ...itineraryResult, 
        blogPost: newBlogPost,
        unlocked: isLoggedIn && (membershipTier === 'Explorer' || membershipTier === 'Cartographer')
      };
      
      setItinerary(finalItinerary);
      saveToRecent(finalItinerary);
      
    } catch (err) { 
      console.error(err);
      alert("Oh no! Something went wrong while I was looking for spots. Let's try that again?"); 
    }
    finally { setLoading(false); }
  };

  const saveToRecent = (trip: TripItinerary) => {
    const updated = [trip, ...recentTrips.filter(t => t.id !== trip.id)].slice(0, 100);
    setRecentTrips(updated);
    localStorage.setItem('whisk_trips', JSON.stringify(updated));
  };
  
  const handleViewPost = (post: BlogPost) => {
    const associatedItinerary = recentTrips.find(trip => trip.id === post.itineraryId);
    if (associatedItinerary) {
      setViewingData({ post, itinerary: associatedItinerary });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  const handleUnlock = () => {
    if (!isLoggedIn) {
      setIsMembershipModalOpen(true);
      return;
    }
    if (itinerary) {
      const updated = { ...itinerary, unlocked: true };
      setItinerary(updated);
      saveToRecent(updated);
    }
  }
  
  const handleReturnHome = () => {
    setItinerary(null);
    setShowForm(false);
    setViewingData(null);
    setActiveTab('home');
  }

  const handleLogOut = () => { 
    setIsLoggedIn(false); 
    setMembershipTier(null);
    localStorage.removeItem('whisk_auth'); 
    localStorage.removeItem('whisk_tier'); 
    handleReturnHome(); 
  };

  const handleSelectTier = (tier: MembershipTier) => {
    setIsLoggedIn(true);
    setMembershipTier(tier);
    localStorage.setItem('whisk_auth', 'true');
    localStorage.setItem('whisk_tier', tier);
    setIsMembershipModalOpen(false);
    if (itinerary) handleUnlock();
  }
  
  // Combine stored user trips with initial community articles to keep the feed populated
  const allArticles: BlogPost[] = [
    ...recentTrips.map(t => t.blogPost).filter((p): p is BlogPost => p !== undefined && p !== null),
    ...INITIAL_ARTICLES.map(p => p as BlogPost)
  ].filter((v, i, a) => a.findIndex(t => t.id === v.id) === i);

  if (viewingData) {
    return (
       <div className="min-h-screen selection:bg-[var(--whisk-orange)] selection:text-white">
         <Navbar isLoggedIn={isLoggedIn} membershipTier={membershipTier} onHome={handleReturnHome} onMyTrips={() => { if(isLoggedIn) setActiveTab('my-trips'); setItinerary(null); setViewingData(null); }} onSignIn={() => setIsMembershipModalOpen(true)} onLogOut={handleLogOut} activeTab={'home'} onUpgrade={() => setIsMembershipModalOpen(true)} />
         <BlogPostDisplay post={viewingData.post} itinerary={viewingData.itinerary} onBack={() => setViewingData(null)} />
         <footer className="bg-[var(--whisk-navy)] text-white py-24"></footer>
       </div>
    )
  }

  return (
    <div className="min-h-screen selection:bg-[var(--whisk-orange)] selection:text-white">
      <Navbar isLoggedIn={isLoggedIn} membershipTier={membershipTier} onHome={handleReturnHome} onMyTrips={() => { if(isLoggedIn) setActiveTab('my-trips'); setItinerary(null); }} onSignIn={() => setIsMembershipModalOpen(true)} onLogOut={handleLogOut} activeTab={activeTab} onUpgrade={() => setIsMembershipModalOpen(true)} />
      
      {loading && (
        <ItinerarySkeleton statusText={loadingStatus} />
      )}
      
      {!loading && !itinerary && !showForm && activeTab === 'home' && (
        <header className="relative min-h-[85vh] flex flex-col items-center justify-center overflow-hidden bg-white">
          <HeroMosaic />
          <div className="max-w-7xl mx-auto px-6 sm:px-10 text-center relative z-10 flex flex-col items-center">
            <div className="vibrant-gradient text-white px-12 py-5 rounded-full text-sm font-black uppercase tracking-[0.5em] mb-12 shadow-2xl animate-pulse cursor-pointer hover:scale-105 transition-all flex items-center gap-4" onClick={() => setShowForm(true)}>
              <Plane className="w-6 h-6" /> Plan My First Trip
            </div>
            <h1 className="text-8xl md:text-[11rem] font-black text-[var(--whisk-navy)] mb-12 tracking-tighter leading-[0.8] drop-shadow-sm">
              Finally, a <br /><span className="text-[var(--whisk-orange)]">Decent Trip.</span>
            </h1>
            <p className="text-3xl text-slate-700 max-w-4xl mx-auto leading-relaxed font-semibold drop-shadow-lg">
              I'll find all the coolest local spots so you can just enjoy the journey. No stress.
            </p>
          </div>
        </header>
      )}

      {!loading && showForm && !itinerary && (
        <TripPlannerForm onGenerate={handleGenerate} loading={loading} />
      )}

      {/* Discover Section - Always visible on Home tab bottom or landing */}
      {!loading && !itinerary && activeTab === 'home' && (
        <>
          <BlogFeed posts={allArticles} onView={handleViewPost} />
          <section className="py-24 bg-slate-50 relative overflow-hidden">
            <div className="max-w-7xl mx-auto px-6">
              <div className="grid md:grid-cols-2 gap-24 items-start">
                <div className="relative">
                  <img src="https://images.unsplash.com/photo-1527631746610-bca00a040d60?q=80&w=2070&auto=format&fit=crop" className="rounded-[5rem] shadow-2xl border-8 border-white" alt="Travel Scene" />
                </div>
                <div className="space-y-12">
                  <h2 className="text-7xl font-black tracking-tighter text-[var(--whisk-navy)] leading-tight">Better Trips, Fast.</h2>
                  <div className="space-y-12">
                    {[
                      { icon: <Heart className="w-10 h-10 fill-[var(--whisk-pink)] text-[var(--whisk-pink)]" />, title: "Vetted Advice", desc: "Only the places I'd tell my best friend about." },
                      { icon: <Zap className="w-10 h-10 text-[var(--whisk-orange)]" />, title: "Ready in Seconds", desc: "A full trip plan in the time it takes to grab a coffee." }
                    ].map((item, i) => (
                      <div key={i} className="flex gap-8 group">
                        <div className="bg-white p-6 rounded-[2rem] h-fit group-hover:scale-110 transition-all shadow-lg border-2 border-slate-50">{item.icon}</div>
                        <div>
                          <h4 className="text-2xl font-black uppercase tracking-widest mb-3 text-[var(--whisk-navy)]">{item.title}</h4>
                          <p className="text-slate-500 font-medium leading-relaxed text-xl">{item.desc}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <TrustTabs />
                </div>
              </div>
            </div>
          </section>
        </>
      )}
      
      {!loading && !itinerary && activeTab === 'my-trips' && (
         <div className="py-32 max-w-7xl mx-auto px-6 sm:px-10 min-h-[60vh]">
             <h2 className="text-7xl font-black mb-20 tracking-tighter text-center text-[var(--whisk-navy)]">My Saved Trips</h2>
             {recentTrips.length > 0 ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-10">
                  {recentTrips.map(trip => (
                    <div key={trip.id} onClick={() => { setItinerary(trip); setActiveTab('home'); }} className="bg-white rounded-[3rem] p-10 shadow-xl border-4 border-white cursor-pointer hover:border-[var(--whisk-orange)] transition-all">
                      <h3 className="text-3xl font-black text-[var(--whisk-navy)] mb-4 tracking-tighter">{trip.title}</h3>
                      <div className="flex items-center gap-2 text-slate-400 font-black uppercase text-[10px] tracking-widest"><MapPin size={14}/> {trip.destination}</div>
                    </div>
                  ))}
                </div>
             ) : (
               <div className="text-center py-20 bg-slate-50 rounded-[4rem] border-4 border-white">
                 <p className="text-2xl text-slate-400 font-bold mb-10">Nothing here yet!</p>
                 <button onClick={handleReturnHome} className="vibrant-gradient text-white px-12 py-6 rounded-[2rem] font-black uppercase tracking-[0.2em] shadow-xl">Start Planning</button>
               </div>
             )}
         </div>
      )}
      
      {itinerary && !loading && (
        <div className="bg-[var(--whisk-sky)]/30 min-h-screen">
          <ItineraryDisplay 
            itinerary={itinerary} 
            onRateActivity={() => {}} 
            onRateOverall={() => {}} 
            onUnlock={handleUnlock}
          />
          <div className="max-w-7xl mx-auto px-6 pb-56 flex flex-col items-center gap-16">
            <button onClick={() => { setItinerary(null); setShowForm(true); }} className="bg-white border-4 border-slate-50 px-20 py-10 rounded-[3.5rem] font-black uppercase tracking-[0.5em] text-sm hover:border-[var(--whisk-orange)] transition-all flex items-center gap-5 shadow-2xl group text-[var(--whisk-navy)]">
              <ChevronRight className="w-8 h-8 rotate-180 group-hover:-translate-x-3 transition-transform" /> Back To Planner
            </button>
          </div>
        </div>
      )}

      <ChatBot />
      <MembershipModal isOpen={isMembershipModalOpen} onClose={() => setIsMembershipModalOpen(false)} onSelectTier={handleSelectTier} />
      <footer className="bg-[var(--whisk-navy)] text-white py-48">
        <div className="max-w-7xl mx-auto px-6 sm:px-10 text-center">
          <div className="flex items-center justify-center gap-5 mb-12">
            <div className="vibrant-gradient p-4 rounded-3xl shadow-xl"><Plane className="w-10 h-10" /></div>
            <span className="text-5xl font-black tracking-tighter uppercase">Whisk</span>
          </div>
          <div className="text-slate-600 text-[12px] font-black uppercase tracking-[0.4em]">© 2024 Whisk Travel. Your best friend's travel advice.</div>
        </div>
      </footer>
    </div>
  );
}
