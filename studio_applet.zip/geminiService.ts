
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { SearchParams, TripItinerary, BlogPost } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * WHISK AFFILIATE INTEGRATION REQUIREMENTS:
 * To use your real affiliate accounts, swap the 'WHISK_PARTNER_ID' placeholder below
 * with your specific IDs for the following providers:
 * 
 * 1. Booking.com: Replace with your 'aid'
 * 2. Viator/TripAdvisor: Replace with your 'mcid'
 * 3. GetYourGuide: Replace with your 'partner_id'
 * 4. Expedia: Replace with your 'siteid' and 'tpid'
 */
const wrapAffiliateLink = (url: string, destination: string, type: string): string => {
  try {
    const urlObj = new URL(url.startsWith('http') ? url : `https://${url}`);
    // Placeholders for the user to fill in later
    urlObj.searchParams.append('ref', 'whisk_bestie');
    urlObj.searchParams.append('partner_id', 'WHISK_PARTNER_ID'); 
    urlObj.searchParams.append('dest', destination.toLowerCase().replace(/\s+/g, '_'));
    return urlObj.toString();
  } catch (e) {
    return url;
  }
};

export const generateItinerary = async (params: SearchParams): Promise<TripItinerary> => {
  // Step 1: Use gemini-3-pro-preview with googleSearch for real-time pricing and availability.
  // We search for current market rates for hotels and flights to the destination.
  const searchResponse = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: `Find real-time pricing and availability for travel to ${params.destination}. 
    I need:
    1. Average flight prices for a ${params.duration} trip.
    2. Real boutique hotels with current nightly rates and room availability status.
    3. Top restaurants and popular tours with pricing if available.
    Use current data from the web to ensure accuracy.`,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const searchData = searchResponse.text;

  // Step 2: Use Flash to structure that grounded data into our required JSON schema.
  const structPrompt = `Convert the following live travel data into a structured JSON itinerary for ${params.destination}.
  
  Live Data Found:
  ${searchData}

  User Preferences:
  - Duration: ${params.duration}
  - Interests: ${params.interests.join(', ')}
  - Budget: ${params.budget}
  - Accessibility: ${params.accessibility.join(', ')}

  Rules:
  1. Talk like a travel bestie.
  2. For each recommendation (hotel, tour, restaurant, flight), you MUST include the 'price' string (e.g., "$150/night") and 'availability' status (e.g., "Only 3 rooms left", "Likely to sell out", "Available").
  3. Ensure all names are real entities found in the search data.
  4. Accessibility requirements MUST be reflected in descriptions.`;

  const structResponse = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: structPrompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          destination: { type: Type.STRING },
          duration: { type: Type.STRING },
          summary: { type: Type.STRING },
          days: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                dayNumber: { type: Type.NUMBER },
                theme: { type: Type.STRING },
                activities: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      time: { type: Type.STRING },
                      description: { type: Type.STRING },
                      location: { type: Type.STRING },
                    },
                    required: ["time", "description", "location"]
                  }
                }
              },
              required: ["dayNumber", "theme", "activities"]
            }
          },
          recommendations: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                type: { type: Type.STRING, enum: ["hotel", "tour", "restaurant", "flight"] },
                description: { type: Type.STRING },
                affiliateUrl: { type: Type.STRING },
                price: { type: Type.STRING },
                availability: { type: Type.STRING }
              },
              required: ["name", "type", "description", "affiliateUrl", "price", "availability"]
            }
          }
        },
        required: ["title", "destination", "duration", "summary", "days", "recommendations"]
      }
    }
  });

  const parsed = JSON.parse(structResponse.text);
  const processedRecommendations = (parsed.recommendations || []).map((rec: any) => ({
    ...rec,
    affiliateUrl: wrapAffiliateLink(rec.affiliateUrl, params.destination, rec.type)
  }));
  
  return {
    ...parsed,
    recommendations: processedRecommendations,
    id: Math.random().toString(36).substring(7),
    createdAt: new Date().toISOString(),
    budget: params.budget,
    pace: params.pace,
    interests: params.interests,
    accessibility: params.accessibility,
    overallRating: 0,
    unlocked: false
  };
};

export const generateBlogPost = async (itinerary: TripItinerary): Promise<Omit<BlogPost, 'id' | 'imageUrl' | 'createdAt'>> => {
    const prompt = `Write a super fun "Field Guide" travel story for ${itinerary.destination} ${itinerary.accessibility && itinerary.accessibility.length > 0 ? `(with a focus on accessibility for: ${itinerary.accessibility.join(', ')})` : ''} based on the trip we just planned.
    
    **Tone:** 100% "Travel Bestie"—exciting, helpful, and friendly.
    
    **The Goal:**
    1. Share why these spots are amazing: ${itinerary.recommendations.map(r => r.name).join(', ')}.
    2. Mention activities like "${itinerary.days[0]?.activities[0]?.location || 'the coolest local spots'}".
    3. Make it sound like a friend telling a story. No corporate talk.
    4. Use Markdown. Use ## for headers.
    5. Give a "Bestie Secret Tip" in a blockquote.
    6. Build hype for the full itinerary without giving every single detail away.`;

    const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    title: { type: Type.STRING },
                    metaDescription: { type: Type.STRING },
                    content: { type: Type.STRING },
                    keywords: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING }
                    }
                },
                required: ["title", "metaDescription", "content", "keywords"]
            }
        }
    });
    const parsed = JSON.parse(response.text);
    return { ...parsed, itineraryId: itinerary.id, destination: itinerary.destination };
};

export const sendChatMessage = async (message: string, history: any[] = []) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: [...history, { role: 'user', parts: [{ text: message }] }],
    config: {
      systemInstruction: "You are Whisk's Travel Bestie. You're high-energy, helpful, and sound like a close personal friend. Never use technical jargon, don't mention AI, and don't talk about 'generating' things. You're just chatting about trips!"
    }
  });
  return response.text;
};

export const sendFastChatMessage = async (message: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-flash-lite-latest',
    contents: message,
    config: {
      systemInstruction: "You are the quick-reply buddy at Whisk. You're like the friend who's always on their phone ready to answer a quick travel question."
    }
  });
  return response.text;
};

export const sendThinkingChatMessage = async (message: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: message,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      systemInstruction: "You are the Master Planner Bestie. You give the deep, well-researched travel advice that only a true expert would know."
    }
  });
  return response.text;
};
