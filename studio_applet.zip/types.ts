
export interface Activity {
  time: string;
  description: string;
  location: string;
  link?: string;
  userRating?: number;
}

export interface DayPlan {
  dayNumber: number;
  theme: string;
  activities: Activity[];
}

export interface Recommendation {
  name: string;
  type: 'hotel' | 'tour' | 'restaurant' | 'flight';
  description: string;
  affiliateUrl: string;
  price?: string;
  availability?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  metaDescription: string;
  content: string; // Markdown content
  keywords: string[];
  itineraryId: string;
  imageUrl: string;
  createdAt: string;
  destination: string;
}

export interface TripItinerary {
  id: string;
  title: string;
  destination: string;
  duration: string;
  summary: string;
  days: DayPlan[];
  recommendations: Recommendation[];
  createdAt: string;
  overallRating?: number;
  budget?: string;
  pace?: string;
  accessibility?: string[];
  interests?: string[];
  blogPost?: BlogPost;
  unlocked?: boolean;
}

export type MembershipTier = 'Wanderer' | 'Explorer' | 'Cartographer';

export interface SearchParams {
  destination: string;
  duration: string;
  interests: string[];
  budget: 'Budget' | 'Mid-range' | 'Luxury';
  pace: 'Relaxed' | 'Moderate' | 'Fast-paced';
  accessibility: string[];
}
