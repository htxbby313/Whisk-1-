import React, { useState } from 'react';
import {
  Sparkles,
  User,
  Mail,
  Compass,
  X,
  Globe,
  ShieldCheck,
  Crown,
  Lock,
  AlertCircle,
} from 'lucide-react';

import { LegalTab } from './LegalModal';

export interface UserProfile {
  name: string;
  email: string;
  travelStyle: string;
  avatarSeed: string;
  isSubscribed: boolean;
  isAdmin?: boolean;
  tripsCount: number;
}

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveProfile: (profile: UserProfile) => void;
  onOpenLegal?: (tab: LegalTab) => void;
}

export default function AuthModal({
  isOpen,
  onClose,
  onSaveProfile,
  onOpenLegal,
}: AuthModalProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [travelStyle, setTravelStyle] = useState('Cultural Explorer');
  const avatarSeed = 'Explorer_1';

  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');
  const [adminError, setAdminError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim()) return;
    onSaveProfile({
      name: name.trim(),
      email: email.trim(),
      travelStyle,
      avatarSeed,
      isSubscribed: false,
      tripsCount: 0,
    });
    onClose();
  };

  const handleQuickGoogleSignIn = () => {
    onSaveProfile({
      name: 'Alex Rivera',
      email: 'alex.rivera@example.com',
      travelStyle: 'Bespoke Adventurer',
      avatarSeed: 'AlexRivera',
      isSubscribed: false,
      tripsCount: 0,
    });
    onClose();
  };

  const handleAdminDemoSignIn = () => {
    onSaveProfile({
      name: 'Coleman (Admin & Chief Scout)',
      email: 'admin@whisk.travel',
      travelStyle: 'Global Expedition Director',
      avatarSeed: 'AdminMaster',
      isSubscribed: true,
      isAdmin: true,
      tripsCount: 24,
    });
    onClose();
  };

  const handleVerifyAdminPassword = () => {
    const clean = adminPassword.trim().toLowerCase();
    if (['whisk2026', 'admin2026', 'admin', 'whiskadmin'].includes(clean)) {
      handleAdminDemoSignIn();
    } else {
      setAdminError('Incorrect Admin Passcode. Access denied.');
    }
  };

  return (
    <div
      className="fixed inset-0 z-[250] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-md"
      role="dialog"
      aria-modal="true"
    >
      <div className="relative w-full max-w-lg bg-gradient-to-b from-[#FFFDF9] via-white to-[#FFF9F2] rounded-[3rem] p-8 md:p-10 shadow-2xl border-4 border-orange-200/70">
        {/* Close Button */}
        <button
          onClick={onClose}
          aria-label="Close auth modal"
          className="absolute top-6 right-6 p-3 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-100 text-orange-700 font-black text-[10px] uppercase tracking-[0.3em] mb-3">
            <Sparkles className="w-3.5 h-3.5 text-orange-500" /> Traveler
            Membership
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight mb-2">
            Create Your Profile
          </h2>
          <p className="text-slate-600 text-sm font-medium">
            Join Whisk to start planning.{' '}
            <span className="text-orange-600 font-bold">
              Your first trip itinerary preview is on us!
            </span>
          </p>
        </div>

        {/* Free Plan Perk Banner */}
        <div className="mb-6 p-4 rounded-2xl bg-gradient-to-r from-amber-50 to-orange-50 border border-amber-200/80 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-orange-500 text-white flex items-center justify-center shrink-0 shadow-md">
            <Globe className="w-5 h-5" />
          </div>
          <div className="text-xs">
            <span className="font-black text-slate-900 block">
              First Trip Preview: 100% Free
            </span>
            <span className="text-slate-500">
              Includes AI day-by-day preview. Upgrade to Passport anytime to
              reveal all days & bookings.
            </span>
          </div>
        </div>

        {/* Admin Demo Password-Gated Access */}
        {!showAdminLogin ? (
          <button
            type="button"
            onClick={() => setShowAdminLogin(true)}
            className="w-full mb-3 py-3 px-4 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg shadow-orange-500/20 hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer border border-amber-300"
          >
            <Lock className="w-4 h-4 text-yellow-200" />
            <span>Admin VIP Access (Password Required)</span>
          </button>
        ) : (
          <div className="mb-4 p-4 rounded-2xl bg-amber-50 border-2 border-orange-300 animate-in fade-in duration-300">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[10px] font-black uppercase tracking-wider text-orange-900 flex items-center gap-1.5">
                <Crown className="w-3.5 h-3.5 fill-orange-600 text-orange-600" />
                Admin Master Passcode Verification
              </span>
              <button
                type="button"
                onClick={() => {
                  setShowAdminLogin(false);
                  setAdminError(null);
                  setAdminPassword('');
                }}
                className="text-[11px] text-slate-400 hover:text-slate-700 font-bold transition-colors cursor-pointer"
              >
                Cancel
              </button>
            </div>
            <div className="flex gap-2">
              <input
                type="password"
                placeholder="Enter master key (whisk2026)"
                value={adminPassword}
                onChange={(e) => {
                  setAdminPassword(e.target.value);
                  if (adminError) setAdminError(null);
                }}
                onKeyDown={(e) =>
                  e.key === 'Enter' && handleVerifyAdminPassword()
                }
                className="flex-1 px-3 py-2.5 bg-white border border-orange-200 rounded-xl text-xs font-semibold outline-none focus:ring-2 focus:ring-orange-500"
                autoFocus
              />
              <button
                type="button"
                onClick={handleVerifyAdminPassword}
                className="px-4 py-2.5 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow cursor-pointer transition-all shrink-0"
              >
                Verify
              </button>
            </div>
            {adminError && (
              <p className="mt-2 text-[11px] text-red-600 font-bold flex items-center gap-1">
                <AlertCircle className="w-3.5 h-3.5" /> {adminError}
              </p>
            )}
            <span className="block mt-2 text-[10px] text-slate-500 font-medium">
              Authorized admin passcode:{' '}
              <strong className="font-mono text-slate-700">whisk2026</strong>
            </span>
          </div>
        )}

        {/* One-click Google Sign-in */}
        <button
          type="button"
          onClick={handleQuickGoogleSignIn}
          className="w-full mb-6 py-3.5 px-4 bg-white hover:bg-slate-50 text-slate-800 border-2 border-slate-200 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-3 shadow-sm hover:shadow transition-all cursor-pointer"
        >
          <svg className="w-4 h-4" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          Continue with Google
        </button>

        <div className="relative flex items-center justify-center mb-6">
          <div className="border-t border-slate-200 w-full"></div>
          <span className="bg-white px-3 text-[10px] font-black uppercase tracking-widest text-slate-400 absolute">
            or complete passport
          </span>
        </div>

        {/* Profile Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">
              Your Explorer Name
            </label>
            <div className="relative">
              <User className="w-4 h-4 text-orange-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                required
                placeholder="e.g. Maya Lin"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">
              Email Address
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-orange-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                placeholder="maya@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-[10px] font-black uppercase tracking-wider text-slate-500 mb-1">
              Travel Vibe
            </label>
            <div className="relative">
              <Compass className="w-4 h-4 text-orange-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <select
                value={travelStyle}
                onChange={(e) => setTravelStyle(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white appearance-none cursor-pointer"
              >
                <option value="Cultural Explorer">Cultural Explorer</option>
                <option value="Island & Coastal Escape">
                  Island & Coastal Escape
                </option>
                <option value="Alpine & Wilderness Adventurer">
                  Alpine & Wilderness Adventurer
                </option>
                <option value="Epicurean & Fine Dining">
                  Epicurean & Fine Dining
                </option>
                <option value="Luxury & Wellness Retreat">
                  Luxury & Wellness Retreat
                </option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="w-full mt-4 py-4 px-6 rounded-2xl bg-gradient-to-r from-orange-500 via-amber-500 to-orange-600 text-white font-black text-xs uppercase tracking-[0.25em] shadow-xl hover:shadow-orange-500/30 hover:scale-[1.01] active:scale-[0.99] transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <ShieldCheck className="w-4 h-4" /> Create Profile & Start Free Trip
          </button>
        </form>

        <p className="mt-4 text-[11px] text-slate-400 text-center leading-relaxed">
          By creating a profile, you agree to Whisk's{' '}
          <button
            type="button"
            onClick={() => onOpenLegal?.('terms')}
            className="underline font-semibold text-slate-600 hover:text-orange-600 transition-colors cursor-pointer"
          >
            Terms of Service (Anti-Circumvention)
          </button>{' '}
          and{' '}
          <button
            type="button"
            onClick={() => onOpenLegal?.('privacy')}
            className="underline font-semibold text-slate-600 hover:text-orange-600 transition-colors cursor-pointer"
          >
            Privacy Policy
          </button>
          .
        </p>
      </div>
    </div>
  );
}
